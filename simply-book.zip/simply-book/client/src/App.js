import React from 'react';
import CustomRoute from './routes';
function App() {
  return (
    <CustomRoute />
  );
}

export default App;
