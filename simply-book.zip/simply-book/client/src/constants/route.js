export const routes = {
    HOME: '/',
    LOGIN: '/login',
    REGISTER: '/register',
    CreateAppointment: '/create'
}
